# Changelog

## [1.0.0] - 2025-01-05

### Added
- Initial release
- Recycler MKI: 25% resource recovery
- Recycler MKII: 50% resource recovery
- Recycler MKIII: 75% resource recovery
- Recycler MKIV: 100% resource recovery (perfect recycling)
- Organic waste output from recycling organic items
- BioProcessing integration: waste feeds into composters
- Configurable recycling speed multiplier
